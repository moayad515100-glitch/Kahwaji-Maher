@echo off
title Kahwaji Maher PC App
echo Starting Kahwaji Maher Desktop Application...
start msedge --app=https://kahwaji-maher.pages.dev || start chrome --app=https://kahwaji-maher.pages.dev || start https://kahwaji-maher.pages.dev
